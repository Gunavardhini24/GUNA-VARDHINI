import React from 'react';
import BaseNode from '../components/BaseNode';

export const FileUploadNode = ({ id, selected }) => {
  return (
    <BaseNode
      title="File Upload"
      subtitle="Upload structured documents"
      icon="📁"
      selected={selected}
      handles={[
        {
          id: `${id}-file`,
          type: 'source',
          position: 'right',
          top: '50%',
        },
      ]}
    >
      <div style={{ color: '#cbd5e1', fontSize: 13 }}>
        Accepts CSV, PDF, JSON and unstructured files.
      </div>
    </BaseNode>
  );
};