import React from 'react';
import BaseNode from '../components/BaseNode';

export const DatabaseNode = ({ id, selected }) => {
  return (
    <BaseNode
      title="Database"
      subtitle="Persistent storage"
      icon="🗄️"
      selected={selected}
      handles={[
        {
          id: `${id}-query`,
          type: 'target',
          position: 'left',
          top: '50%',
        },
        {
          id: `${id}-result`,
          type: 'source',
          position: 'right',
          top: '50%',
        },
      ]}
    >
      <div style={{ color: '#cbd5e1', fontSize: 13 }}>
        Execute queries against persistent data sources.
      </div>
    </BaseNode>
  );
};
