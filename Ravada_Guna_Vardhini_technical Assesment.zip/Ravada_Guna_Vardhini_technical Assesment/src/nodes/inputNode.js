import React, { useState } from 'react';

import BaseNode from '../components/BaseNode';

export const InputNode = ({ id, selected }) => {

  const [inputType, setInputType] = useState('Text');

  const [textValue, setTextValue] = useState('');

  const [jsonValue, setJsonValue] = useState('');

  const [fileName, setFileName] = useState('');

  const [summary, setSummary] = useState('');

  // FILE UPLOAD HANDLER
  
  const handleFileUpload = (event) => {

    const file = event.target.files[0];

    if (file) {

      setFileName(file.name);

      const reader = new FileReader();

      reader.onload = (e) => {

        setTextValue(e.target.result);

      };

      reader.readAsText(file);
    }
  };

  
  // GENERATE AI SUMMARY

  const generateSummary = async () => {

    try {

      setSummary('Generating summary...');

      const response = await fetch(
        'http://127.0.0.1:8000/ai/generate',
        {
          method: 'POST',

          headers: {
            'Content-Type': 'application/json',
          },

          body: JSON.stringify({
            prompt:
              'Summarize the following content:\n\n' +
              textValue,
          }),
        }
      );

      const data = await response.json();

      if (data.success) {

        setSummary(data.response);

      } else {

        setSummary('Failed to generate summary.');
      }

    } catch (error) {

      console.error(error);

      setSummary('Error generating summary.');
    }
  };

  return (
    <BaseNode
      title="Input"
      subtitle="Workflow Data Source"
      icon="📥"
      selected={selected}
      width={320}
      handles={[
        {
          id: `${id}-output`,
          type: 'source',
          position: 'right',
          top: '50%',
        },
      ]}
    >
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: 14,
        }}
      >

        {/* INPUT TYPE SELECTOR */}

        <div>

          <div
            style={{
              color: '#94a3b8',
              fontSize: 12,
              marginBottom: 6,
            }}
          >
            Input Type
          </div>

          <select
            value={inputType}
            onChange={(e) =>
              setInputType(e.target.value)
            }
            style={{
              width: '100%',
              background: '#0f172a',
              border: '1px solid #334155',
              color: '#f8fafc',
              padding: '10px 12px',
              borderRadius: 10,
              outline: 'none',
            }}
          >
            <option>Text</option>
            <option>File</option>
            <option>JSON</option>
          </select>

        </div>

        {/* TEXT INPUT */}

        {inputType === 'Text' && (

          <textarea
            value={textValue}
            onChange={(e) =>
              setTextValue(e.target.value)
            }
            placeholder="Enter workflow input text..."
            style={{
              width: '100%',
              minHeight: 90,
              resize: 'none',
              background: '#0f172a',
              border: '1px solid #334155',
              color: '#f8fafc',
              padding: 12,
              borderRadius: 12,
              outline: 'none',
              fontSize: 13,
              lineHeight: 1.6,
            }}
          />

        )}

        {/* FILE INPUT */}

        {inputType === 'File' && (

          <div
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: 10,
            }}
          >

            <label
              style={{
                background: '#172554',
                color: '#bfdbfe',
                border: '1px solid #1d4ed8',
                borderRadius: 12,
                padding: '10px 14px',
                textAlign: 'center',
                cursor: 'pointer',
                fontSize: 13,
                fontWeight: 600,
              }}
            >
              Upload File

              <input
                type="file"
                accept=".txt,.csv,.json"
                onChange={handleFileUpload}
                style={{ display: 'none' }}
              />
            </label>

            {fileName && (

              <div
                style={{
                  background: '#0f172a',
                  border: '1px solid #334155',
                  padding: 10,
                  borderRadius: 10,
                  color: '#cbd5e1',
                  fontSize: 12,
                }}
              >
                Uploaded: {fileName}
              </div>

            )}

          </div>

        )}

        {/* JSON INPUT */}

        {inputType === 'JSON' && (

          <textarea
            value={jsonValue}
            onChange={(e) =>
              setJsonValue(e.target.value)
            }
            placeholder='{\n  "customer": "John",\n  "feedback": "Delivery delayed"\n}'
            style={{
              width: '100%',
              minHeight: 120,
              resize: 'none',
              background: '#0f172a',
              border: '1px solid #334155',
              color: '#f8fafc',
              padding: 12,
              borderRadius: 12,
              outline: 'none',
              fontSize: 13,
              lineHeight: 1.6,
              fontFamily: 'monospace',
            }}
          />

        )}

        {/* GENERATE SUMMARY BUTTON */}

        <button
          onClick={generateSummary}
          style={{
            background: '#2563eb',
            color: '#ffffff',
            border: 'none',
            borderRadius: 12,
            padding: '12px',
            cursor: 'pointer',
            fontWeight: 700,
            fontSize: 13,
          }}
        >
          Generate AI Summary
        </button>

        {/* SUMMARY OUTPUT */}

        {summary && (

          <div
            style={{
              background: '#0f172a',
              border: '1px solid #334155',
              padding: 14,
              borderRadius: 12,
              color: '#e2e8f0',
              fontSize: 13,
              lineHeight: 1.7,
            }}
          >
            {summary}
          </div>

        )}

      </div>
    </BaseNode>
  );
};