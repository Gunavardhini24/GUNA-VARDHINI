import React, {
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
} from 'react';

import { Position } from 'reactflow';

import BaseNode from '../components/BaseNode';
import { extractVariables } from '../utils/variableParser';

export const TextNode = ({ id, data, selected }) => {
  const [text, setText] = useState(
    data?.text || 'Hello {{name}} from {{company}}'
  );

  const textareaRef = useRef(null);

  const variables = useMemo(
    () => extractVariables(text),
    [text]
  );

  useLayoutEffect(() => {
    const textarea = textareaRef.current;

    if (!textarea) return;

    textarea.style.height = 'auto';
    textarea.style.height = `${textarea.scrollHeight}px`;

    textarea.style.width = '100%';
  }, [text]);

  // Dynamic variable handles
  const dynamicHandles = variables.map(
    (variable, index) => ({
      id: `${id}-${variable}`,
      type: 'target',
      position: Position.Left,
      top: `${30 + index * 18}%`,
      style: {
        background: '#3b82f6',
        border: '2px solid #bfdbfe',
      },
    })
  );

  // Stable output handle
  const outputHandle = {
    id: `${id}-output`,
    type: 'source',
    position: Position.Right,
    top: '50%',
    style: {
      background: '#8b5cf6',
      border: '2px solid #ddd6fe',
    },
  };

  return (
    <BaseNode
      title="Text"
      subtitle="Dynamic template node"
      icon="📝"
      selected={selected}
      width={340}
      handles={[...dynamicHandles, outputHandle]}
    >
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: 16,
        }}
      >
        <div className="node-field">
          <label
            className="node-label"
            style={{
              color: '#94a3b8',
              fontSize: 12,
              marginBottom: 8,
              display: 'block',
              fontWeight: 600,
            }}
          >
            Template Content
          </label>

          <textarea
            ref={textareaRef}
            value={text}
            rows={1}
            onChange={(e) => setText(e.target.value)}
            placeholder="Write dynamic prompt content..."
            style={{
              width: '100%',
              minHeight: 100,
              resize: 'none',
              overflow: 'hidden',
              background: '#0f172a',
              border: '1px solid #334155',
              color: '#f8fafc',
              padding: 14,
              borderRadius: 14,
              outline: 'none',
              fontSize: 13,
              lineHeight: 1.7,
              transition: 'all 0.2s ease',
            }}
          />
        </div>

        {variables.length > 0 && (
          <div>
            <div
              style={{
                color: '#94a3b8',
                fontSize: 12,
                marginBottom: 10,
                fontWeight: 600,
              }}
            >
              Detected Variables
            </div>

            <div
              style={{
                display: 'flex',
                flexWrap: 'wrap',
                gap: 8,
              }}
            >
              {variables.map((variable) => (
                <div
                  key={variable}
                  style={{
                    background: '#172554',
                    color: '#bfdbfe',
                    padding: '6px 10px',
                    borderRadius: 999,
                    fontSize: 12,
                    border: '1px solid #1d4ed8',
                    fontWeight: 500,
                  }}
                >
                  {variable}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </BaseNode>
  );
};