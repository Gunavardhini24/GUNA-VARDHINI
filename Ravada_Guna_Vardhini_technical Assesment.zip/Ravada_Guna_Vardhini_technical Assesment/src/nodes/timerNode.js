import React from 'react';
import BaseNode from '../components/BaseNode';

export const TimerNode = ({ id, selected }) => {
  return (
    <BaseNode
      title="Timer"
      subtitle="Scheduled execution"
      icon="⏰"
      selected={selected}
      handles={[
        {
          id: `${id}-tick`,
          type: 'source',
          position: 'right',
          top: '50%',
        },
      ]}
    >
      <div style={{ color: '#cbd5e1', fontSize: 13 }}>
        Run workflows on recurring schedules.
      </div>
    </BaseNode>
  );
};