import React from 'react';
import BaseNode from '../components/BaseNode';

export const WebhookNode = ({ id, selected }) => {
  return (
    <BaseNode
      title="Webhook"
      subtitle="External integration"
      icon="🌐"
      selected={selected}
      handles={[
        {
          id: `${id}-request`,
          type: 'target',
          position: 'left',
          top: '50%',
        },
        {
          id: `${id}-response`,
          type: 'source',
          position: 'right',
          top: '50%',
        },
      ]}
    >
      <div style={{ color: '#cbd5e1', fontSize: 13 }}>
        Trigger REST API calls and receive responses.
      </div>
    </BaseNode>
  );
};