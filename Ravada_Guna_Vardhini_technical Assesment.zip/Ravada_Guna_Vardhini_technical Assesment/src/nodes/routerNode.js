import React from 'react';
import BaseNode from '../components/BaseNode';

export const RouterNode = ({ id, selected }) => {
  return (
    <BaseNode
      title="Conditional Router"
      subtitle="Branch execution logic"
      icon="🔀"
      selected={selected}
      handles={[
        {
          id: `${id}-input`,
          type: 'target',
          position: 'left',
          top: '50%',
        },
        {
          id: `${id}-true`,
          type: 'source',
          position: 'right',
          top: '35%',
        },
        {
          id: `${id}-false`,
          type: 'source',
          position: 'right',
          top: '70%',
        },
      ]}
    >
      <div style={{ color: '#cbd5e1', fontSize: 13 }}>
        Routes workflow execution depending on conditions.
      </div>
    </BaseNode>
  );
};