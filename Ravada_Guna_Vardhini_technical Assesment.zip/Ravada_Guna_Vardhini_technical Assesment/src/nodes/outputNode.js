import React, { useState } from 'react';
import BaseNode from '../components/BaseNode';

export const OutputNode = ({ id, data, selected }) => {
  const [outputName, setOutputName] = useState(
    data?.outputName || 'output'
  );

  const [outputType, setOutputType] = useState(
    data?.outputType || 'Text'
  );

  return (
    <BaseNode
      title="Output"
      subtitle="Pipeline result"
      icon="📤"
      selected={selected}
      handles={[
        {
          id: `${id}-input`,
          type: 'target',
          position: 'left',
          top: '50%',
        },
      ]}
    >
      <div className="node-field">
        <label className="node-label">
          Output Name
        </label>

        <input
          className="node-input"
          value={outputName}
          onChange={(event) =>
            setOutputName(event.target.value)
          }
          placeholder="Enter output name"
        />
      </div>

      <div className="node-field">
        <label className="node-label">
          Output Type
        </label>

        <select
          className="node-select"
          value={outputType}
          onChange={(event) =>
            setOutputType(event.target.value)
          }
        >
          <option>Text</option>
          <option>JSON</option>
          <option>Markdown</option>
          <option>File</option>
        </select>
      </div>

      <div className="output-preview">
        <div className="output-preview-label">
          OUTPUT STATUS
        </div>

        <div className="output-preview-text">
          Pipeline result ready for export
        </div>
      </div>
    </BaseNode>
  );
};