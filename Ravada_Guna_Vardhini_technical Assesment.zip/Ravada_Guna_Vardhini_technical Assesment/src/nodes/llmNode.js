import React, { useState } from 'react';
import BaseNode from '../components/BaseNode';

export const LLMNode = ({ id, selected }) => {
  const [loading, setLoading] = useState(false);

  const [response, setResponse] = useState('');

  const generateResponse = (type) => {
    setLoading(true);

    setResponse('');

    setTimeout(() => {
      const mockResponses = {
        Summarization:
          'Customers are experiencing delayed deliveries and requesting faster shipping updates.',

        Classification:
          'Support Ticket Priority: High Priority',

        'Sentiment Analysis':
          'Overall customer sentiment appears negative due to delivery delays.',

        Extraction:
          'Extracted Entities: Customer Name, Delivery Date, Tracking ID',

        'AI Reasoning':
          'Workflow execution completed successfully based on upstream contextual inputs.',
      };

      setResponse(mockResponses[type]);

      setLoading(false);
    }, 1200);
  };

  const capabilities = [
    'AI Reasoning',
    'Summarization',
    'Sentiment Analysis',
    'Classification',
    'Extraction',
  ];

  return (
    <BaseNode
      title="AI GPT Turbo"
      subtitle="Enterprise AI Processing Engine"
      icon="🧠"
      selected={selected}
      width={360}
      handles={[
        {
          id: `${id}-system`,
          type: 'target',
          position: 'left',
          top: '35%',
        },
        {
          id: `${id}-prompt`,
          type: 'target',
          position: 'left',
          top: '65%',
        },
        {
          id: `${id}-response`,
          type: 'source',
          position: 'right',
          top: '50%',
        },
      ]}
    >
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: 16,
        }}
      >
        <div
          style={{
            color: '#cbd5e1',
            lineHeight: 1.7,
            fontSize: 13,
          }}
        >
          Process workflow prompts, analyze contextual data,
          and generate intelligent AI-powered responses using
          advanced language model capabilities.
        </div>

        <div
          style={{
            background: '#111827',
            border: '1px solid #374151',
            borderRadius: 16,
            padding: 14,
          }}
        >
          <div
            style={{
              color: '#94a3b8',
              fontSize: 11,
              marginBottom: 6,
            }}
          >
            ACTIVE AI MODEL
          </div>

          <div
            style={{
              color: '#f8fafc',
              fontSize: 15,
              fontWeight: 700,
            }}
          >
            GPT-4 Turbo
          </div>
        </div>

        <div
          style={{
            display: 'flex',
            flexWrap: 'wrap',
            gap: 8,
          }}
        >
          {capabilities.map((tag) => (
            <button
              key={tag}
              onClick={() => generateResponse(tag)}
              style={{
                background: '#172554',
                color: '#bfdbfe',
                border: '1px solid #1d4ed8',
                borderRadius: 999,
                padding: '6px 12px',
                fontSize: 11,
                fontWeight: 600,
                cursor: 'pointer',
                transition: 'all 0.2s ease',
              }}
            >
              {tag}
            </button>
          ))}
        </div>

        {(loading || response) && (
          <div
            style={{
              background: '#0f172a',
              border: '1px solid #334155',
              borderRadius: 14,
              padding: 14,
              color: '#e2e8f0',
              fontSize: 13,
              lineHeight: 1.6,
              minHeight: 70,
            }}
          >
            {loading
              ? 'Generating AI response...'
              : response}
          </div>
        )}
      </div>
    </BaseNode>
  );
};