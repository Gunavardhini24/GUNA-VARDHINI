export const extractVariables = (text) => {
  // Regex to find variables like {{name}}
  const regex = /{{\s*([a-zA-Z_$][a-zA-Z0-9_$]*)\s*}}/g;

  // Use Set to avoid duplicate variables
  const variables = new Set();

  let match;

  // Loop through all matches
  while ((match = regex.exec(text)) !== null) {
    variables.add(match[1]);
  }

  // Convert Set to Array
  return Array.from(variables);
};