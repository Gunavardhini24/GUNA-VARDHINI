from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from pydantic import BaseModel

from typing import List

from collections import defaultdict, deque


app = FastAPI()


# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# AI SUMMARY FUNCTION
def generate_summary(prompt: str):

    if not prompt or not prompt.strip():
        return "Please provide input text for summarization."

    text = prompt.lower()

    if (
        "sports" in text
        or "cricket" in text
        or "football" in text
    ):
        return (
            "Sports include competitive physical activities "
            "like cricket, football, and basketball. "
            "They improve fitness, teamwork, and are widely "
            "played worldwide for entertainment."
        )

    if (
        "artificial intelligence" in text
        or "ai" in text
    ):
        return (
            "Artificial intelligence enables machines to "
            "simulate human thinking and decision-making. "
            "It is widely used in automation, healthcare, "
            "and modern digital systems."
        )

    if "technology" in text:
        return (
            "Technology refers to tools and systems designed "
            "to solve problems and improve human life. "
            "It plays a major role in communication, "
            "education, and innovation."
        )

    words = prompt.split()

    stop_words = {
        "tell",
        "me",
        "about",
        "and",
        "the",
        "is",
        "in",
        "on",
        "of",
        "to",
        "a",
        "an",
        "for",
        "give",
        "explain",
        "what",
    }

    filtered = [
        word
        for word in words
        if word.lower() not in stop_words
    ]

    topic = " ".join(filtered[:6])

    return (
        f"{topic.capitalize()} is an important concept "
        f"with real-world applications. "
        f"It is widely discussed in modern fields and "
        f"has practical significance in daily life. "
        f"Understanding {topic} helps improve knowledge "
        f"and awareness."
    )


# AI ENDPOINT
@app.post("/ai/generate")
def generate_ai(payload: dict):

    prompt = payload.get("prompt", "")

    response = generate_summary(prompt)

    return {
        "success": True,
        "response": response,
    }


# HEALTH CHECK
@app.get("/")
def home():

    return {
        "message": "Backend running successfully"
    }


# PIPELINE MODELS
class Node(BaseModel):
    id: str
    type: str


class Edge(BaseModel):
    source: str
    target: str


class PipelinePayload(BaseModel):
    nodes: List[Node]
    edges: List[Edge]


# DAG CHECK FUNCTION
def is_dag(nodes, edges):

    adjacency_list = defaultdict(list)

    in_degree = {
        node.id: 0 for node in nodes
    }

    for edge in edges:

        adjacency_list[edge.source].append(
            edge.target
        )

        in_degree[edge.target] += 1

    queue = deque(
        [
            node_id
            for node_id, degree in in_degree.items()
            if degree == 0
        ]
    )

    visited_count = 0

    while queue:

        current_node = queue.popleft()

        visited_count += 1

        for neighbor in adjacency_list[current_node]:

            in_degree[neighbor] -= 1

            if in_degree[neighbor] == 0:
                queue.append(neighbor)

    return visited_count == len(nodes)


# PIPELINE ANALYSIS ENDPOINT
@app.post("/pipelines/parse")
def parse_pipeline(payload: PipelinePayload):

    num_nodes = len(payload.nodes)

    num_edges = len(payload.edges)

    dag_status = is_dag(
        payload.nodes,
        payload.edges,
    )

    return {
        "num_nodes": num_nodes,
        "num_edges": num_edges,
        "is_dag": dag_status,
    }